import { betterAuth } from 'better-auth';
import { drizzleAdapter } from 'better-auth/adapters/drizzle';
import { db } from '@/lib/db';
export const auth = betterAuth({ database: drizzleAdapter(db, { provider: 'pg' }), emailAndPassword: { enabled: true, requireEmailVerification: false }, trustedOrigins: [process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000'], user: { modelName: 'users', additionalFields: {} }, session: { modelName: 'session' }, account: { modelName: 'account' }, verification: { modelName: 'verification' } });
export const OWNER_EMAIL = (process.env.OWNER_EMAIL || 'randhejayaprakash@gmail.com').toLowerCase();
