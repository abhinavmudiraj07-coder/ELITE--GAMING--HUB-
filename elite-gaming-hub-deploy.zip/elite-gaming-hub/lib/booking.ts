import { randomUUID } from 'crypto';
import { sql } from '@/lib/db';

export function makeReference(){ return 'EGH-' + Math.random().toString(36).slice(2,8).toUpperCase(); }
export async function createBooking(input:any){
  const {customerName,phone,service,gameId,bookingDate,startTime,durationMinutes,players,customerOptIn=false}=input;
  if(!customerName?.trim() || !/^\+?[0-9\s-]{10,15}$/.test(phone||'')) throw new Error('Enter a valid name and phone number.');
  if(!['PS5','PS4','GTA6','STEERING'].includes(service)) throw new Error('Invalid service.');
  if(![30,60,120].includes(durationMinutes)) throw new Error('Invalid duration.');
  if(service==='GTA6' && ![30,60,120].includes(durationMinutes)) throw new Error('Invalid GTA 6 duration.');
  if(service==='STEERING' && durationMinutes===120) throw new Error('Steering wheel supports 30 or 60 minutes.');
  if(service!=='GTA6' && service!=='STEERING' && durationMinutes===120) throw new Error('120 minutes is only available for GTA 6.');
  if(service!=='GTA6' && service!=='STEERING' && (players<1 || players>4)) throw new Error('Choose 1–4 players.');
  const start = new Date(`${bookingDate}T${startTime}:00+05:30`); const end = new Date(start.getTime()+durationMinutes*60000);
  if(Number.isNaN(start.getTime()) || start < new Date(Date.now()+10*60000)) throw new Error('Choose a future time at least 10 minutes from now.');
  const hhmm = (d:Date)=>d.toLocaleTimeString('en-GB',{timeZone:'Asia/Kolkata',hour:'2-digit',minute:'2-digit',hour12:false});
  const endTime=hhmm(end); if(startTime<'10:00' || endTime>'22:00') throw new Error('Bookings must fit within 10:00 AM–10:00 PM.');
  const amountRows=await sql`SELECT amount FROM pricing WHERE service=${service} AND duration_minutes=${durationMinutes} AND players=${(service==='PS5'||service==='PS4')?players:1} LIMIT 1`;
  const amountRow=amountRows[0];
  if(!amountRow) throw new Error('No price is configured for this selection.');
  // Serializable transaction + row locks: availability is rechecked immediately before insertion.
  const result:any = await sql.begin('isolation level serializable', async tx=>{
    const resources= service==='PS5' || service==='GTA6' ? await tx`SELECT id FROM consoles WHERE service='PS5' AND status='AVAILABLE' ORDER BY id FOR UPDATE` : await tx`SELECT id FROM consoles WHERE service=${service} AND status='AVAILABLE' ORDER BY id FOR UPDATE`;
    const active=await tx`SELECT console_id FROM bookings WHERE booking_date=${bookingDate} AND status='CONFIRMED' AND start_time < ${endTime}::time AND end_time > ${startTime}::time`;
    const blocked=await tx`SELECT console_id FROM blocked_slots WHERE booking_date=${bookingDate} AND start_time < ${endTime}::time AND end_time > ${startTime}::time`;
    const used=new Set([...active,...blocked].map((r:any)=>r.console_id));
    const chosen=resources.find((r:any)=>!used.has(r.id)); if(!chosen) throw new Error('Sorry, this time slot is no longer available. Please choose another.');
    const ref=makeReference(); const id=randomUUID();
    await tx`INSERT INTO bookings (id,reference,customer_name,phone,service,game_id,console_id,booking_date,start_time,end_time,duration_minutes,players,amount,status,payment_status,customer_opt_in) VALUES (${id},${ref},${customerName.trim()},${phone.trim()},${service},${gameId||null},${chosen.id},${bookingDate},${startTime},${endTime},${durationMinutes},${players},${amountRow.amount},'CONFIRMED','PENDING',${!!customerOptIn})`;
    return {id,reference:ref,consoleId:chosen.id,amount:amountRow.amount,endTime};
  });
  return result;
}
