export const defaultPricing = [
  ...[1,2,3,4].flatMap(players => [{service:'PS5',durationMinutes:30,players,amount:[70,100,130,160][players-1]},{service:'PS5',durationMinutes:60,players,amount:[130,190,260,320][players-1]}]),
  ...[1,2,3,4].flatMap(players => [{service:'PS4',durationMinutes:30,players,amount:[50,80,110,140][players-1]},{service:'PS4',durationMinutes:60,players,amount:[100,150,200,250][players-1]}]),
  {service:'GTA6',durationMinutes:30,players:1,amount:80},{service:'GTA6',durationMinutes:60,players:1,amount:160},{service:'GTA6',durationMinutes:120,players:1,amount:300},
  {service:'STEERING',durationMinutes:30,players:1,amount:100},{service:'STEERING',durationMinutes:60,players:1,amount:190}
] as const;
