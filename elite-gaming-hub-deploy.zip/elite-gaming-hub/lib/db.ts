import postgres from 'postgres';
import { drizzle } from 'drizzle-orm/postgres-js';
import * as schema from '@/db/schema';
const url = process.env.DATABASE_URL;
if (!url) throw new Error('DATABASE_URL is missing. Copy .env.example to .env.local and add your Neon connection string.');
// postgres.js supports interactive transactions required for safe console allocation.
export const sql = postgres(url, { ssl: 'require', prepare: false, max: 1 });
export const db = drizzle(sql, { schema });
