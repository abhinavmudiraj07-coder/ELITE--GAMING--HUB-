CREATE EXTENSION IF NOT EXISTS btree_gist;
-- Enforce no overlapping confirmed bookings on the same physical console at database level.
ALTER TABLE bookings ADD CONSTRAINT no_overlapping_confirmed_bookings
EXCLUDE USING gist (
  console_id WITH =,
  booking_date WITH =,
  (tsrange((booking_date + start_time), (booking_date + end_time), '[)')) WITH &&
) WHERE (status = 'CONFIRMED');
