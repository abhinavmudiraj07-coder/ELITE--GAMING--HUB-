# ELITE GAMING HUB — deployable website project

A Next.js + TypeScript application for Elite Gaming Hub, Eluru. It includes the supplied logo and five real store photographs, the game catalogue transcribed from the supplied four-page PDF, booking and customer lookup screens, Neon/PostgreSQL schema, Better Auth owner sign-in, pricing endpoints and optional WhatsApp Cloud API owner notifications.

## Important deployment status

This ZIP is a **deployable project, not an already-published website**. No GitHub, Vercel, Neon or Meta account has been connected from this chat. There is no live URL yet. You must create the accounts/projects and add their secrets before customers can use it.

## 1. Create Neon database

1. Open https://neon.tech from your Android browser and create a project.
2. Copy the pooled PostgreSQL connection string.
3. Keep it private. Never paste it into frontend code or a public GitHub file.

## 2. Upload to GitHub and deploy on Vercel

1. Extract this ZIP.
2. Create a GitHub repository and upload the project contents (not the ZIP itself).
3. Import the repository at https://vercel.com.
4. In Vercel → Project → Settings → Environment Variables, add the variables from `.env.example`.
5. Set `DATABASE_URL` to the Neon pooled connection string.
6. Set `BETTER_AUTH_SECRET` to a unique random secret of at least 32 characters.
7. Set `BETTER_AUTH_URL` and `NEXT_PUBLIC_SITE_URL` to the Vercel production URL after the first deployment; redeploy after setting them.
8. Build command: `npm run build`; install command: `npm install`.

## 3. Run database migrations and seed initial data

From a local terminal or GitHub Codespaces terminal (Android browser is supported):

```bash
npm install
cp .env.example .env.local
# Edit .env.local with your Neon connection string and auth secret
npm run db:generate
npm run db:migrate
npm run db:seed
```

If using Vercel without a local terminal, use GitHub Codespaces or another Node.js terminal to run these commands. Do not put the database URL into a browser-side environment variable.

After Drizzle migrations create the tables, run the following SQL once in Neon SQL Editor to enforce a database-level no-overlap constraint:

```sql
CREATE EXTENSION IF NOT EXISTS btree_gist;
ALTER TABLE bookings ADD CONSTRAINT no_overlapping_confirmed_bookings
EXCLUDE USING gist (
  console_id WITH =,
  booking_date WITH =,
  (tsrange((booking_date + start_time), (booking_date + end_time), '[)')) WITH &&
) WHERE (status = 'CONFIRMED');
```

The booking API also uses a PostgreSQL SERIALIZABLE transaction and rechecks compatible resources before inserting. If you run the SQL constraint a second time, PostgreSQL will report that the constraint already exists; do not add it twice.

## 4. Create the owner login

The only email allowed to use owner API endpoints is:

`randhejayaprakash@gmail.com`

Set `OWNER_INITIAL_PASSWORD` in your private terminal environment (12+ characters), then run:

```bash
npm run owner:create
```

Use that email and password at `/admin`. A successful login with another email will not grant admin API access. Keep the owner password private. If you create the owner account before production deployment, ensure it is the same Neon database used by Vercel.

## 5. WhatsApp Cloud API (optional)

To send owner booking notifications, configure a Meta WhatsApp Business Cloud API app and set:

- `WHATSAPP_ACCESS_TOKEN`
- `WHATSAPP_PHONE_NUMBER_ID`
- `WHATSAPP_OWNER_NUMBER` (international format, digits only)
- `WHATSAPP_API_VERSION`

The app logs configured/not-configured and sent/failed notification attempts. A notification failure does not cancel a saved booking. Meta business verification, templates/permissions and production messaging eligibility are outside this repository and must be completed in Meta Business Manager. Customer WhatsApp confirmations are not enabled in this first deployable build; customer opt-in is captured and stored.

## 6. Routes

- `/` — home
- `/about` — about the centre
- `/games` — searchable PS5 / PS4 library
- `/book` — booking form
- `/customer` — booking lookup using reference + phone number
- `/contact` — contact and map link
- `/admin` — owner sign-in and booking/payment overview

## 7. Initial catalogue and prices

The seed file uses the supplied four-page PDF as its primary game-list reference. Page 1 and page 2 list PS5 titles; pages 3 and 4 list PS4 titles and pricing. Repeated titles are consolidated where the title and console match. The written rates in the build brief are seeded for PS5, PS4, GTA 6 and steering wheel.

The source PDF contains no GTA 6-specific rate, so the GTA 6 rates in this app come from the written brief: ₹80 / ₹160 / ₹300 for 30 / 60 / 120 minutes. Steering-wheel rates come from the written brief: ₹100 / ₹190 for 30 / 60 minutes.

## 8. Known limitations to finish before public launch

This is a functional foundation and not yet a verified production release. Before taking real bookings, test the complete deployment against the actual Neon project. In particular:

- Admin booking list and payment status editing are implemented; full calendar, console maintenance, operating-hours editor, manual booking, reschedule/cancel controls, game CRUD, analytics and reports still need to be completed.
- The customer lookup is a reference + exact phone match, not an OTP-verified customer account. Do not treat it as strong identity verification for sensitive data.
- The availability endpoint returns real reservations, but the booking UI currently asks for a start time and relies on the server-side transaction to accept/reject it; it does not yet render a live per-console slot calendar.
- Live push updates/SSE are not implemented; availability is fetched from the database when requested.
- WhatsApp owner notification requires Meta credentials and has no scheduled retry worker yet. Customer WhatsApp messages are not sent.
- Before launch, confirm the actual game inventory and supported-player details in-store. The source PDF has inconsistent duplicate/numbering entries across pages; descriptions and genres are short editorial summaries, not copied from the PDF.
- Confirm the migration and exclusion-constraint SQL work in the target Neon region and run simultaneous-booking tests before public use.

## 9. Local development

```bash
npm install
npm run db:generate
npm run db:migrate
npm run db:seed
npm run dev
```

Open http://localhost:3000.
