import { auth, OWNER_EMAIL } from '../lib/auth';
const password=process.env.OWNER_INITIAL_PASSWORD;
if(!password || password.length<12) throw new Error('Set OWNER_INITIAL_PASSWORD (12+ characters) before running npm run owner:create');
const result=await auth.api.signUpEmail({body:{name:'Elite Gaming Hub Owner',email:OWNER_EMAIL,password}});
console.log('Owner account created:',result.user.email); process.exit(0);
