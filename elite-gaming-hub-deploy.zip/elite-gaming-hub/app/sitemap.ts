import type {MetadataRoute} from 'next';
export default function sitemap():MetadataRoute.Sitemap{const base=process.env.NEXT_PUBLIC_SITE_URL||'https://elitegaminghub.in';return ['','/about','/games','/book','/contact','/customer'].map(path=>({url:`${base}${path}`,lastModified:new Date()}));}
