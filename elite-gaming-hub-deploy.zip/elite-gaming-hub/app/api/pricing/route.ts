import {NextResponse} from 'next/server';import {db} from '@/lib/db';import {pricing} from '@/db/schema';
export async function GET(){return NextResponse.json({pricing:await db.select().from(pricing)});}
