import {NextResponse} from 'next/server';import {db} from '@/lib/db';import {games} from '@/db/schema';import {eq} from 'drizzle-orm';
export async function GET(){return NextResponse.json({games:await db.select().from(games).where(eq(games.active,true))});}
